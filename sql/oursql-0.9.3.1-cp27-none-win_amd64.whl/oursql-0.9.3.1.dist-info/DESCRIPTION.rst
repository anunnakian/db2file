oursql is a set of MySQL bindings for python 2.4+ with a focus on 
wrapping the `MYSQL_STMT API`__ to provide real parameterization and 
real server-side cursors. MySQL 4.1.2 or better is required.

__ http://dev.mysql.com/doc/refman/5.0/en/c-api-prepared-statements.html

There's extensive documentation available online at 
http://packages.python.org/oursql/.


